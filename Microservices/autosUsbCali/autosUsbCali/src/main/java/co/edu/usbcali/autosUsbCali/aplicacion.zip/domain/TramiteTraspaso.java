package co.edu.usbcali.autosUsbCali.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

@Entity
@Table(name = "tramites_traspaso")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class TramiteTraspaso {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "venta_id", nullable = false)
    private Venta venta;

    // Valores permitidos: INICIADO, EN_TRAMITE, EN_TRANSITO, COMPLETADO, RECHAZADO
    @Column(name = "estado", length = 20, nullable = false)
    private String estado;

    @Column(name = "observaciones")
    private String observaciones;

    @ManyToOne
    @JoinColumn(name = "usuario_gestiona_id")
    private Usuario usuarioGestiona;

    @Column(name = "fecha_inicio", nullable = false)
    private OffsetDateTime fechaInicio;

    @Column(name = "fecha_completado")
    private OffsetDateTime fechaCompletado;
}
