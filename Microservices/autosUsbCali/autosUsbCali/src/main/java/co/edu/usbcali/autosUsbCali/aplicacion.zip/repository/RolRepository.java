package co.edu.usbcali.autosUsbCali.repository;

import co.edu.usbcali.autosUsbCali.domain.Rol;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RolRepository extends JpaRepository<Rol, Long> {
    Optional<Rol> findByNombre(String name);
    List<Rol> findByActivo(Boolean activo);
    Boolean existsByNombre(String nombre);
    Boolean existsByNombreAndIdNot(String nombre, Long id);
}
