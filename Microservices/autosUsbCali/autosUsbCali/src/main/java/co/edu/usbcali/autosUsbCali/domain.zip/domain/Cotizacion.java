package co.edu.usbcali.autosUsbCali.domain;

public class Cotizacion {
}
